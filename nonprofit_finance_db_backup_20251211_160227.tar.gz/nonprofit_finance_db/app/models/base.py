from typing import NewType
ID = NewType("ID", int)