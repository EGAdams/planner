from .base import BaseRepository

class ReportRepository(BaseRepository):
    table = "reports"