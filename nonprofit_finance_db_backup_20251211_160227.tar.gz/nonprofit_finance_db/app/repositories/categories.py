from .base import BaseRepository

class CategoryRepository(BaseRepository):
    table = "categories"