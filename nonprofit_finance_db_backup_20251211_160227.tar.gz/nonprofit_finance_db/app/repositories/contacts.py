from .base import BaseRepository

class ContactRepository(BaseRepository):
    table = "contacts"