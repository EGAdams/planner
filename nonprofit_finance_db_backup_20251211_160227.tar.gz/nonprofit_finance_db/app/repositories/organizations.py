from .base import BaseRepository

class OrganizationRepository(BaseRepository):
    table = "organizations"