# low budget way to track already parsed pdf documents

```python
pdf_path = "/mnt/c/Users/NewUser/Downloads/fifth_third_personal_june.pdf"
```
