# GEMINI.md

## Project Overview

This project is a Python-based interactive chat interface for a persistent Letta orchestrator. The Letta orchestrator is an agent that can delegate tasks to specialized agents. The agent's memory is persistent across sessions, and it can be reset if needed.

The project is structured into three main components:

1.  **Chat Interface:** (`chat_with_letta.py`) A command-line interface for interacting with the Letta agent.

2.  **Agent Management:** (`agent_management/`) A Python module for creating, managing, and interacting with the Letta agent. It includes a persistent agent that remembers tasks across sessions and a set of tools for code generation, testing, and TDD validation.

3.  **Node.js Bridges:** (`node_executables/`) A set of Node.js scripts that act as bridges between the Python code and the Codex SDK. These scripts are used to run the Coder and Tester agents.

## Building and Running

### Prerequisites

*   Python 3.8+
*   Node.js 18+
*   `letta-client` Python package
*   `@openai/codex-sdk` NPM package

### Environment Variables

The following environment variables are required:

*   `LETTA_BASE_URL`: The URL of the Letta server (defaults to `http://localhost:8283`).
*   `OPENAI_API_KEY`: Your OpenAI API key.
*   `CODEX_MODEL`: The Codex model to use for code generation (e.g., `gpt-5.1-codex`).

### Running the Chat Interface

To start the interactive chat interface, run the following command:

```bash
python3 chat_with_letta.py
```

You can also reset the agent's memory by running:

```bash
python3 chat_with_letta.py --reset
```

### Running the TDD Orchestrator

To run the TDD orchestrator, you can run the `hybrid_letta__codex_sdk.py` script directly:

```bash
python3 -m agent_management.hybrid_letta__codex_sdk
```

This will create a new Letta agent, register the TDD tools, and then send a pre-defined user task to the agent.

## Development Conventions

*   **Code Style:** The project uses the `black` code formatter and `flake8` for linting.

*   **Modularity:** The project is highly modular, with a clear separation of concerns between the chat interface, agent management, and Node.js bridges.
