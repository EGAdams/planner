
# 🧠 Letta Orchestrator Setup & Debugging Guide

## ✅ 1. PostgreSQL Access & Authentication

### 🔍 Problem:
Initial attempts to connect using `psql -U postgres -h localhost` failed with:
```
fe_sendauth: no password supplied
```

### ✅ Solution:
We identified the correct credentials by inspecting the `LETTA_PG_URI`:

```
postgresql+pg8000://letta:letta@localhost:5432/letta
```

Which led to successful connection via:

```bash
PGPASSWORD=letta psql -U letta -d letta -h localhost
```

---

## 🧱 2. Letta DB Table Missing

### 🔍 Problem:
Querying `llm_providers` table failed:
```
ERROR:  relation "llm_providers" does not exist
```

### ✅ Solution:
You correctly suspected Letta doesn’t have a UI for managing LLM providers, so we pivoted to defining everything through Python code using the Letta client API.

---

## 🔑 3. Google Generative Language API Access Error

### 🔍 Problem:
Tried to use:
```bash
curl -H "Authorization: Bearer $(gcloud auth application-default print-access-token)" ...
```
But hit:
```
Command 'gcloud' not found ...
"Method doesn't allow unregistered callers"
```

### ✅ Solution:
- Realized you need to use an API Key, not an OAuth token.
- You were using the wrong identity mechanism for this particular Google API.
- Recommendation: Register your API key in your Google Cloud Console and pass it using `?key=YOUR_API_KEY`.

---

## ⚙️ 4. Letta Agent Configuration & `thinking_budget`

### 🔍 Problem:
No `thinking_budget` was passed when creating the orchestrator agent, which may cause undesired default behavior.

### ✅ Solution:
We confirmed that `1024` is a safe, default value used elsewhere in the repo.

You can safely create your orchestrator like this:

```python
agent = client.agents.create(
    model=ORCH_MODEL,
    thinking_budget=1024,
    ...
)
```

---

## 🧠 5. Memory Block Setup for Orchestrator Agent

### ✅ Working Configuration:
We reviewed and validated the correct setup for the persistent orchestrator with memory blocks and tools:

```python
memory_blocks=[
    {
        "label": "role",
        "value": "...CRITICAL MEMORY RULES...",
        "limit": 3000,
    },
    {
        "label": "task_history",
        "value": "No tasks completed yet.",
        "limit": 5000,
    },
    {
        "label": "workspace",
        "value": f"Workspace directory: {WORKSPACE_DIR}",
        "limit": 1000,
    }
],
```

Combined with correct tool environment bindings:

```python
tool_exec_environment_variables={
    "ORCH_MODEL": ORCH_MODEL,
    "WORKSPACE_DIR": str(WORKSPACE_DIR),
    "CODEX_MODEL": os.environ.get("CODEX_MODEL", ""),
    "CONTRACT_LOG_NAME": CONTRACT_LOG_NAME,
    "CODEX_NODE_BRIDGE": os.environ.get("CODEX_NODE_BRIDGE", ""),
},
```

---

## 🛠️ Final Checklist for Smooth Operation

| Task | Completed |
|------|-----------|
| PostgreSQL login credentials tested | ✅ |
| Letta database verified | ✅ |
| Agent creation script validated | ✅ |
| Environment variables passed correctly | ✅ |
| `thinking_budget` confirmed | ✅ |
| Memory blocks for role, history, workspace setup | ✅ |
| Google API integration guidance provided | ✅ |

---

## 📌 Tips for the Future

- Use `PGPASSWORD=letta` if prompted again for the PostgreSQL password.
- If you get `relation does not exist`, re-verify your Letta version or database schema.
- Prefer API keys for Google Gemini endpoints.
- Check for `thinking_budget` or `memory_limit` if agents behave unexpectedly.
- Always keep a backup of working `agent.create(...)` Python snippets like the one above.
