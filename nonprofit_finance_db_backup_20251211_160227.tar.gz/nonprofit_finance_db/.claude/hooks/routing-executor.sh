#!/bin/bash

# No-op: routing is hub-only; this hook is disabled by config
exit 0